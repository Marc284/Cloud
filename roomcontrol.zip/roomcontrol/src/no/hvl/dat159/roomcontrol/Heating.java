package no.hvl.dat159.roomcontrol;

public class Heating {

	private Room room;
		
	public Heating (Room room) {
		this.room = room;
	}
	
	public void write (boolean newvalue) {
		System.out.println("SWITCH: " + newvalue);
		room.actuate(newvalue);
	}
	
	
}
