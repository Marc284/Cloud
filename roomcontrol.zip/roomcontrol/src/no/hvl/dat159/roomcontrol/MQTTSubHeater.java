package no.hvl.dat159.roomcontrol;


import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class MQTTSubHeater implements MqttCallback, Runnable {

	private String message;
	private Heating heat;

	public MQTTSubHeater(Heating heat) throws MqttException {

		String topic = "Heat";
		int qos = 1; // 1 - This client will acknowledge to the Device Gateway that messages are
						// received
		String broker = "tcp://m15.cloudmqtt.com:12627";
		String clientId = "MQTT_Heating_SUB";
		String username = "reawpgmz";
		String password = "nCCIqNZoklGw";

		this.heat = heat;

		MqttConnectOptions connOpts = new MqttConnectOptions();
		connOpts.setCleanSession(true);
		connOpts.setUserName(username);
		connOpts.setPassword(password.toCharArray());

		System.out.println("Connecting to broker: " + broker);

		MqttClient client = new MqttClient(broker, clientId, new MemoryPersistence());
		client.setCallback(this);
		client.connect(connOpts);
		System.out.println("Connected");

		client.subscribe(topic, qos);
		System.out.println("Subscribed to message");

	}

	/**
	 * @see MqttCallback#connectionLost(Throwable)
	 */
	public void connectionLost(Throwable cause) {
		System.out.println("Connection lost because: " + cause);
		System.exit(1);

	}

	/**
	 * @see MqttCallback#messageArrived(String, MqttMessage)
	 */
	public void messageArrived(String topic, MqttMessage message) throws Exception {

//		String dismessage = String.format("%s", new String(message.getPayload()));
//		
//		int i = Integer.parseInt(dismessage);
		
		String switching = new String (message.getPayload());
		
		System.out.println("ON/OFF:" + switching);
		
		if(switching.equals("1")) {
			heat.write(true);
		}
		else if (switching.equals("0")) {
			heat.write(false);
		}
		

		this.setMessage(new String(message.getPayload()));
	}

	/**
	 * @see MqttCallback#deliveryComplete(IMqttDeliveryToken)
	 */
	public void deliveryComplete(IMqttDeliveryToken token) {
		// TODO Auto-generated method stub

	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public static void main(String args[]) throws MqttException {
		

	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
