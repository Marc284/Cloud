package no.hvl.dat159.roomcontrol;

public class Controller {
	
	public static void main(String[] args) {
		
	}
	
	public void controll(double message) {
		System.out.println("Message" + message);
		MQTTPubHeaterController heaterpub;
		if(message<15) {
			 heaterpub = new MQTTPubHeaterController(1);
		}
		else {
			 heaterpub = new MQTTPubHeaterController(0);
		}
		
		try {
			
			Thread temppublisher = new Thread(heaterpub);
			
			temppublisher.start();
			
			temppublisher.join();
			
		} catch (Exception ex) {
			
			System.out.println("Controller: " + ex.getMessage());
			ex.printStackTrace();
		}
		
	}

	
	
}
