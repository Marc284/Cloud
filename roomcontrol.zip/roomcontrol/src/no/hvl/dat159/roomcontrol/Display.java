package no.hvl.dat159.roomcontrol;

public class Display {

	public void write(String message) {
		System.out.println("DISPLAY: " + message);
	}
	
}
